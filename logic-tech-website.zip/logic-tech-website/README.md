# Logic Tech Website

Official modern and responsive static website for **Logic Tech** — Delivering tailored IT solutions, cloud infrastructure, cybersecurity, custom software engineering, and digital transformation.

## 🚀 Features

- **Modern Glassmorphic UI**: High-impact visuals, responsive layouts, smooth micro-interactions, and dark mode palette.
- **Full Page Suite**:
  - `index.html`: Home page with service highlights, stats, testimonials, and interactive contact modal.
  - `about.html`: Company vision, leadership, and core values.
  - `services.html`: In-depth breakdown of IT solutions & service packages.
  - `how-it-works.html`: 4-step client engagement & project lifecycle.
  - `case-studies.html`: Client success stories and metrics.
  - `faq.html`: Frequently asked questions with interactive accordion.
  - `contact.html`: Contact forms, office location, and direct inquiries.
  - `login.html`, `register.html`, `forgot-password.html`: Client portal authentication screens.
  - `dashboard-client.html`: Client dashboard with project progress, ticketing, and invoices.
- **Pure Web Stack**: HTML5, Vanilla CSS, and JavaScript with zero heavy runtime dependencies.

## 🛠️ Getting Started

Open any `.html` file (e.g. `index.html`) directly in any modern web browser or serve using a static web server:

```bash
# Using Python
python -m http.server 8080

# Using Node.js (npx serve or live-server)
npx serve .
```
